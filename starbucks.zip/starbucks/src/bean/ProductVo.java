package bean;

public class ProductVo {

	
	String item_code;
	int item_postnum;
	String item_group;
	String item_title;
	String item_content;
	int item_savedmoney;
	String item_theme;
	String item_size;
	int item_price;
	int item_num;
	String item_mainimg;
	String item_thumnailimg;
	String item_contentimg;
	int order_sumnum;
	String item_regDate;
	
	
	public String getItem_code() {
		return item_code;
	}
	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}
	public int getItem_postnum() {
		return item_postnum;
	}
	public void setItem_postnum(int item_postnum) {
		this.item_postnum = item_postnum;
	}
	public String getItem_group() {
		return item_group;
	}
	public void setItem_group(String item_group) {
		this.item_group = item_group;
	}
	public String getItem_title() {
		return item_title;
	}
	public void setItem_title(String item_title) {
		this.item_title = item_title;
	}
	public String getItem_content() {
		return item_content;
	}
	public void setItem_content(String item_content) {
		this.item_content = item_content;
	}
	public int getItem_savedmoney() {
		return item_savedmoney;
	}
	public void setItem_savedmoney(int item_savedmoney) {
		this.item_savedmoney = item_savedmoney;
	}
	public String getItem_theme() {
		return item_theme;
	}
	public void setItem_theme(String item_theme) {
		this.item_theme = item_theme;
	}
	public String getItem_size() {
		return item_size;
	}
	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}
	public int getItem_price() {
		return item_price;
	}
	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}
	public int getItem_num() {
		return item_num;
	}
	public void setItem_num(int item_num) {
		this.item_num = item_num;
	}
	public String getItem_mainimg() {
		return item_mainimg;
	}
	public void setItem_mainimg(String item_mainimg) {
		this.item_mainimg = item_mainimg;
	}
	public String getItem_thumnailimg() {
		return item_thumnailimg;
	}
	public void setItem_thumnailimg(String item_thumnailimg) {
		this.item_thumnailimg = item_thumnailimg;
	}
	public String getItem_contentimg() {
		return item_contentimg;
	}
	public void setItem_contentimg(String item_contentimg) {
		this.item_contentimg = item_contentimg;
	}
	public int getOrder_sumnum() {
		return order_sumnum;
	}
	public void setOrder_sumnum(int order_sumnum) {
		this.order_sumnum = order_sumnum;
	}
	public String getItem_regDate() {
		return item_regDate;
	}
	public void setItem_regDate(String item_regDate) {
		this.item_regDate = item_regDate;
	}
	
	
}
